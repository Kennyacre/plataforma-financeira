// js/login.js

// ==========================================
// 1. MOTOR DE LOGIN NORMAL (Utilizador e Senha)
// ==========================================
document.getElementById('formLogin').addEventListener('submit', async function (e) {
    e.preventDefault();

    const emailDigitado = document.getElementById('email').value;
    const passDigitada = document.getElementById('password').value;
    const msgErro = document.getElementById('mensagemErro');
    const btn = document.getElementById('btn-submit-login');

    const textoOriginal = btn.innerHTML;
    btn.innerHTML = '<span class="material-symbols-rounded">hourglass_empty</span> Autenticando...';
    btn.disabled = true;

    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: emailDigitado.toLowerCase().trim(), password: passDigitada })
        });

        const result = await response.json();

        if (response.ok && result.status === "sucesso") {
            // GRAVA O CRACHÁ COMPLETO NO NAVEGADOR
            localStorage.setItem('usuarioLogado', result.username);
            localStorage.setItem('funcaoUsuario', result.role);

            const role = result.role.toLowerCase();
            redirecionarPorRole(role);
        } else {
            msgErro.style.display = 'block';
            msgErro.innerText = result.detail || "Utilizador ou senha incorretos!";
            btn.innerHTML = textoOriginal;
            btn.disabled = false;
        }
    } catch (error) {
        console.error("Erro no motor:", error);
        msgErro.style.display = 'block';
        msgErro.innerText = "Erro ao conectar com o servidor.";
        btn.innerHTML = textoOriginal;
        btn.disabled = false;
    }
});

// ==========================================
// 2. MOTOR DO GOOGLE
// ==========================================
window.handleGoogleLogin = async function (response) {
    const tokenGoogle = response.credential;
    const loader = document.getElementById('google-loading');

    if (loader) loader.style.display = 'block';

    try {
        const res = await fetch('/api/auth/google', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ token: tokenGoogle })
        });

        const result = await res.json();

        if (res.ok && result.status === "sucesso") {
            const role = result.role.toLowerCase();
            localStorage.setItem('usuarioLogado', result.username);
            localStorage.setItem('funcaoUsuario', result.role);

            if (result.novo_usuario) {
                document.getElementById('modalIndicacao').style.display = 'flex';
                window.tempRole = role;
            } else {
                redirecionarPorRole(role);
            }
        } else {
            console.error("Google Auth failed:", result);
            // Mostra erro apenas se não for auto-fail silencioso do Google
            if (result.detail) {
                alert("❌ O Servidor Recusou Google: " + result.detail);
            }
        }
    } catch (error) {
        console.error("Erro Crítico Google:", error);
    } finally {
        if (loader) loader.style.display = 'none';
    }
};

async function finalizarVinculo() {
    const user = localStorage.getItem('usuarioLogado');
    const idRef = document.getElementById('idIndicacao').value || 4; // 4 é o Admin padrão
    const btn = document.getElementById('btnConfirmarIndicacao');

    btn.disabled = true;
    btn.innerText = 'Redirecionando...';

    try {
        await fetch('/api/vincular-indicacao', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username: user, indicacao_id: parseInt(idRef) })
        });
    } catch (e) {
        console.error("Erro ao vincular:", e);
    }
    redirecionarPorRole(window.tempRole || 'cliente');
}

function redirecionarPorRole(role) {
    role = role.toLowerCase();
    if (role === 'admin' || role === 'gerente') {
        window.location.href = 'gerente/painel-admin.html';
    } else if (role === 'revenda') {
        alert("⚠️ O acesso de Revendedor está em manutenção.");
        window.location.reload();
    } else {
        window.location.href = 'cliente/painel-cliente.html';
    }
}
