// gerente/js/todos-clientes.js

// Usamos adminLogado para não dar o erro do "user already declared"
const adminLogado = localStorage.getItem('usuarioLogado');

document.addEventListener('DOMContentLoaded', () => {
    if (typeof inicializarSidebar === 'function') inicializarSidebar();

    const elNome = document.getElementById('nome-admin-sidebar');
    if (elNome) elNome.innerText = adminLogado ? adminLogado.toUpperCase() : 'ADMIN';

    carregarUsuariosGlobais();
});

async function carregarUsuariosGlobais() {
    try {
        const response = await fetch('/api/admin/todos-usuarios');
        const data = await response.json();

        const tbody = document.getElementById('lista-usuarios');
        if (!tbody) return;
        tbody.innerHTML = '';

        if (!data.usuarios || data.usuarios.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align: center;">Nenhum cliente no radar.</td></tr>';
            return;
        }

        data.usuarios.forEach(u => {
            // Lógica de Bloqueio
            const isBloqueado = u.status === 'bloqueado';
            const iconBloqueio = isBloqueado ? 'lock_open' : 'block';
            const corBloqueio = isBloqueado ? '#10b981' : '#f59e0b';
            const labelBloqueio = isBloqueado ? 'Desbloquear' : 'Bloquear';

            let acoes = '';
            if (u.username !== 'admin') {
                acoes = `
                    <div style="display: flex; gap: 8px; justify-content: flex-end;">
                        <button onclick="toggleBloqueio(${u.id}, '${u.username}')" title="${labelBloqueio}" style="background: rgba(255,255,255,0.05); color: ${corBloqueio}; border: 1px solid rgba(255,255,255,0.1); padding: 6px; border-radius: 8px; cursor: pointer;">
                            <span class="material-symbols-rounded" style="font-size: 18px;">${iconBloqueio}</span>
                        </button>
                        <button onclick="excluirUsuario(${u.id}, '${u.username}')" title="Mover para Lixeira" style="background: rgba(239, 68, 68, 0.1); color: #ef4444; border: 1px solid rgba(239, 68, 68, 0.2); padding: 6px; border-radius: 8px; cursor: pointer;">
                            <span class="material-symbols-rounded" style="font-size: 18px;">delete</span>
                        </button>
                    </div>
                `;
            }

            let badgeColor = u.role.toLowerCase() === 'admin' ? '#f59e0b' : (u.role.toLowerCase() === 'revenda' ? '#8b5cf6' : '#10b981');
            let badgeBg = u.role.toLowerCase() === 'admin' ? 'rgba(245, 158, 11, 0.1)' : (u.role.toLowerCase() === 'revenda' ? 'rgba(139, 92, 246, 0.1)' : 'rgba(16, 185, 129, 0.1)');

            tbody.innerHTML += `
                <tr class="user-row">
                    <td style="color: #94a3b8;">#${u.id}</td>
                    <td class="nome-user" style="font-weight: bold; color: ${isBloqueado ? '#64748b' : '#f8fafc'};">
                        ${u.nome} <br>
                        <small style="color: #64748b; font-weight: normal;">@${u.username}</small> ${isBloqueado ? '<small>(Bloqueado)</small>' : ''}
                    </td>
                    <td><span style="background: ${badgeBg}; color: ${badgeColor}; padding: 4px 10px; border-radius: 20px; font-size: 11px; font-weight: bold; text-transform: uppercase;">${u.role}</span></td>
                    <td style="color: #94a3b8;">${u.revendedor || 'Sistema'}</td>
                    <td style="color: #94a3b8;">${u.vencimento || 'Sem data'}</td>
                    <td>${acoes}</td>
                </tr>
            `;
        });
    } catch (error) {
        console.error("Erro no radar:", error);
        document.getElementById('lista-usuarios').innerHTML = '<tr><td colspan="6" style="text-align: center; color: #ef4444;">Falha de comunicação com a base de dados.</td></tr>';
    }
}

async function toggleBloqueio(id, username) {
    try {
        const response = await fetch(`/api/admin/bloquear/${id}`, { method: 'POST' });
        if (response.ok) {
            const data = await response.json();
            carregarUsuariosGlobais(); // Atualiza a tela
            alert(`O status de ${username} foi alterado para: ${data.novo_status.toUpperCase()}`);
        } else {
            const result = await response.json();
            alert("Erro: " + (result.detail || "Falha ao mudar status."));
        }
    } catch (error) { alert("Erro de conexão."); }
}

async function excluirUsuario(id, username) {
    if (!confirm(`⚠️ Deseja mover '${username}' para a lixeira?`)) return;
    try {
        const response = await fetch(`/api/admin/usuarios/${id}`, { method: 'DELETE' });
        if (response.ok) {
            carregarUsuariosGlobais();
        } else {
            alert("Erro ao excluir.");
        }
    } catch (error) { alert("Erro de conexão."); }
}

function filtrarTabela() {
    const filter = document.getElementById('filtro-users').value.toLowerCase();
    const rows = document.querySelectorAll('.user-row');
    rows.forEach(row => {
        const nome = row.querySelector('.nome-user').innerText.toLowerCase();
        row.style.display = nome.includes(filter) ? "" : "none";
    });
}