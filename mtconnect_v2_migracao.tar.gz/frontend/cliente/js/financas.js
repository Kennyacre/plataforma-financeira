// cliente/js/financas.js
const user = localStorage.getItem('usuarioLogado');

document.addEventListener('DOMContentLoaded', async () => {
    // 1. Segurança e Sidebar
    if (typeof inicializarSidebar === 'function') inicializarSidebar();

    const elNome = document.getElementById('nome-cliente-sidebar');
    const elAvatar = document.getElementById('user-avatar');
    if(elNome) elNome.innerText = user.toUpperCase();
    if(elAvatar) elAvatar.innerText = user.substring(0,2).toUpperCase();

    // 2. Carregar Motor Financeiro
    await carregarDadosFinancas();
});

async function carregarDadosFinancas() {
    try {
        const res = await fetch(`/api/lancamentos/${user}`);
        const data = await res.json();
        const lancamentos = data.dados || [];

        let totalReceitas = 0;
        let totalDespesas = 0;
        let categoriasGastos = {};

        // Varre todos os lançamentos
        lancamentos.forEach(l => {
            const valor = parseFloat(l.valor);
            if (l.tipo === 'recebimento') {
                totalReceitas += valor;
            } else {
                totalDespesas += valor;
                // Agrupar os gastos por categoria para o gráfico
                const cat = l.categoria || 'Outros';
                categoriasGastos[cat] = (categoriasGastos[cat] || 0) + valor;
            }
        });

        const saldo = totalReceitas - totalDespesas;

        // Atualiza a Grelha de Valores
        document.getElementById('total-receitas').innerText = formatarMoeda(totalReceitas);
        document.getElementById('total-despesas').innerText = formatarMoeda(totalDespesas);
        document.getElementById('saldo-atual').innerText = formatarMoeda(saldo);

        // Renderiza o Gráfico Donut com as categorias de despesas
        renderizarGraficoDonut(categoriasGastos);
    } catch (error) {
        console.error("Erro ao carregar finanças", error);
    }
}

function formatarMoeda(valor) {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(valor);
}

function renderizarGraficoDonut(dadosCategorias) {
    const ctx = document.getElementById('financasChart').getContext('2d');
    
    const labels = Object.keys(dadosCategorias);
    const values = Object.values(dadosCategorias);

    // Se não houver dados, não desenha o gráfico
    if (values.length === 0) return;

    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: values,
                // Paleta de cores Premium para as categorias
                backgroundColor: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899', '#14b8a6'],
                borderWidth: 4,
                borderColor: '#1e293b', // Mesma cor do fundo do card
                hoverOffset: 10
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '70%', // O buraco maior no meio que você configurou (design elegante)
            plugins: {
                legend: {
                    position: 'right',
                    labels: { 
                        padding: 20, 
                        usePointStyle: true, 
                        pointStyle: 'circle', 
                        color: '#f8fafc',
                        font: { size: 13, family: "'Inter', sans-serif" } 
                    }
                },
                tooltip: {
                    backgroundColor: 'rgba(15, 23, 42, 0.9)',
                    titleFont: { size: 14, family: "'Inter', sans-serif" },
                    bodyFont: { size: 14, weight: 'bold' },
                    padding: 15,
                    cornerRadius: 10,
                    callbacks: {
                        label: function(context) {
                            return ' R$ ' + context.parsed.toFixed(2).replace('.', ',');
                        }
                    }
                }
            }
        }
    });
}