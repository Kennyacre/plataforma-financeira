const user = localStorage.getItem('usuarioLogado');

// Formatação de moeda para o padrão Brasileiro
const formatarMoeda = (valor) => {
    return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(valor);
};

// ==========================================
// MOTOR DO PAINEL LATERAL (NOVA TRANSAÇÃO)
// ==========================================
function abrirPainelTransacao(modo, id = null) {
    const painel = document.getElementById('painelTransacao');
    const overlay = document.getElementById('overlayPainel');
    const titulo = document.getElementById('tituloPainelTransacao');

    if (modo === 'nova') {
        titulo.innerText = "Nova Transação";
        document.getElementById('formLancamento').reset();
        document.getElementById('idTransacaoEditar').value = '';
        document.getElementById('dataLancamento').valueAsDate = new Date(); // Hoje
    }

    painel.classList.add('aberto');
    setTimeout(() => overlay.classList.add('aberto'), 10);
}

// === INFRAESTRUTURA DE SELECTORS DINÂMICOS ===
async function carregarOpcoesCategorias() {
    const sel = document.getElementById('catLancamento');
    if (!sel) return;
    try {
        const res = await fetch(`/api/categorias/${user}`);
        const data = await res.json();
        sel.innerHTML = '<option value="" disabled selected>Selecione...</option>';
        const padroes = ["Alimentação", "Moradia", "Transporte", "Saúde", "Lazer e Viagens", "Educação", "Salário", "Vestuário", "Investimentos", "Impostos / Taxas", "Cuidados Pessoais", "Outros"];
        padroes.forEach(p => sel.add(new Option(p, p)));
        if (data.status === 'sucesso' && data.dados.length > 0) {
            sel.add(new Option("── MINHAS CATEGORIAS ──", "", false, false)).disabled = true;
            data.dados.forEach(c => sel.add(new Option(c.nome, c.nome)));
        }
    } catch (e) { console.error("Erro ao carregar categorias:", e); }
}

async function carregarOpcoesPagamento() {
    const sel = document.getElementById('pagLancamento');
    if (!sel) return;
    try {
        const res = await fetch(`/api/formas-pagamento/${user}`);
        const data = await res.json();
        sel.innerHTML = '<option value="" disabled selected>Selecione...</option>';
        const padroes = ["PIX", "Dinheiro", "Boleto", "Saldo em Conta", "Cartão de Crédito", "Cartão de Débito", "Transferência", "Outros"];
        padroes.forEach(p => sel.add(new Option(p, p)));

        // Buscar Cartões também
        const resC = await fetch(`/api/cartoes/${user}`);
        const dataC = await resC.json();
        if (dataC.status === 'sucesso' && dataC.cartoes.length > 0) {
            sel.add(new Option("── SEUS CARTÕES ──", "", false, false)).disabled = true;
            dataC.cartoes.forEach(c => sel.add(new Option(`💳 ${c.nome}`, c.nome)));
        }

        if (data.status === 'sucesso' && data.dados.length > 0) {
            sel.add(new Option("── MINHAS FORMAS ──", "", false, false)).disabled = true;
            data.dados.forEach(f => sel.add(new Option(f.nome, f.nome)));
        }
    } catch (e) { console.error("Erro ao carregar pagamentos:", e); }
}

function fecharPainelTransacao() {
    const painel = document.getElementById('painelTransacao');
    const overlay = document.getElementById('overlayPainel');

    painel.classList.remove('aberto');
    overlay.classList.remove('aberto');
    setTimeout(() => overlay.style.display = 'none', 300);
}

// ==========================================
// ENVIAR DADOS DO FORMULÁRIO (SALVAR NO BANCO)
// ==========================================
const formLancamento = document.getElementById('formLancamento');
if (formLancamento) {
    formLancamento.addEventListener('submit', async function (e) {
        e.preventDefault();

        const btn = document.getElementById('btn-salvar-transacao');
        const textoOriginal = btn.innerText;
        btn.innerText = "Salvando...";
        btn.disabled = true;

        const isEdit = document.getElementById('idTransacaoEditar').value !== "";

        const payload = {
            username: user,
            tipo: document.getElementById('tipoLancamento').value,
            descricao: document.getElementById('descLancamento').value,
            valor: parseFloat(document.getElementById('valorLancamento').value),
            data: document.getElementById('dataLancamento').value,
            categoria: document.getElementById('catLancamento').value,
            pagamento: document.getElementById('pagLancamento').value,
            repetir: "nao",
            quantidade: 1
        };

        try {
            const url = isEdit ? `/api/lancamentos/${document.getElementById('idTransacaoEditar').value}` : '/api/lancamentos';
            const method = isEdit ? 'PUT' : 'POST';

            const response = await fetch(url, {
                method: method,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            const result = await response.json();

            if (response.ok) {
                alert(isEdit ? "Transação atualizada!" : "Transação salva com sucesso!");
                fecharPainelTransacao();
                window.location.reload(); // Recarrega para atualizar os saldos
            } else {
                alert("Erro: " + result.detail);
            }
        } catch (error) {
            console.error("Erro:", error);
            alert("Erro ao conectar com o servidor.");
        } finally {
            btn.innerText = textoOriginal;
            btn.disabled = false;
        }
    });
}

// ==========================================
// CARREGAMENTO DOS DADOS (SALDOS E GRÁFICOS)
// ==========================================
document.addEventListener('DOMContentLoaded', async () => {
    // Se o usuário não estiver logado, nem tenta puxar dados
    if (!user) {
        console.warn("Usuário não encontrado. Volte para o Login.");
        return;
    }

    // Escreve o e-mail/nome na barra lateral
    const elNome = document.getElementById('nome-cliente-sidebar');
    const elAvatar = document.getElementById('user-avatar');
    if (elNome) elNome.innerText = user.split('@')[0].toUpperCase();
    if (elAvatar) elAvatar.innerText = user.substring(0, 2).toUpperCase();

    // Tenta carregar o nome real se existir
    try {
        const resP = await fetch(`/api/usuarios/perfil/${user}`);
        if (resP.ok) {
            const dataP = await resP.json();
            if (dataP.nome_completo && elNome) {
                elNome.innerText = dataP.nome_completo.split(' ')[0].toUpperCase();
            }
        }
    } catch (e) { }

    // Lógica do Menu Responsivo
    const btnToggle = document.getElementById('btn-toggle-sidebar');
    const sidebar = document.getElementById('minha-sidebar');
    if (btnToggle && sidebar) {
        btnToggle.addEventListener('click', () => {
            sidebar.classList.toggle('escondida');
        });
    }

    // Carregar opções dos selectors (Categorias e Pagamentos)
    await Promise.all([
        carregarOpcoesCategorias(),
        carregarOpcoesPagamento()
    ]);

    // Puxa os dados do Python (APIs)
    try {
        // 1. Puxar Saldo e Receitas
        const resStats = await fetch(`/api/dashboard-stats/${user}`);
        if (resStats.ok) {
            const stats = await resStats.json();
            document.getElementById('saldo-valor').innerText = formatarMoeda(stats.saldo);
            document.getElementById('receitas-valor').innerText = formatarMoeda(stats.receitas);
            document.getElementById('despesas-valor').innerText = formatarMoeda(stats.despesas);
        }

        // 2. Puxar Dados do Gráfico de Evolução (Barras)
        const resChart = await fetch(`/api/chart-data/${user}`);
        if (resChart.ok) {
            const chartData = await resChart.json();
            renderizarGraficoBarras(chartData);
        }

        // 3. Puxar Cartões de Crédito
        const resCartoes = await fetch(`/api/cartoes/${user}`);
        if (resCartoes.ok) {
            const dataCartoes = await resCartoes.json();
            renderizarWidgetCartoes(dataCartoes.cartoes);
        }

        // 4. Puxar Transações para as Pizzas
        const resLancamentos = await fetch(`/api/lancamentos/${user}`);
        if (resLancamentos.ok) {
            const dataLanc = await resLancamentos.json();
            processarDadosParaPizzas(dataLanc.dados);
        }
    } catch (error) {
        console.error("Erro de comunicação com o Python:", error);
    }
});

// ==========================================
// FUNÇÕES DOS GRÁFICOS (CHART.JS)
// ==========================================
function renderizarGraficoBarras(dados) {
    const canvas = document.getElementById('financeChart');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: dados.labels,
            datasets: [
                { label: 'Receitas', data: dados.receitas, backgroundColor: '#10b981', borderRadius: 4 },
                { label: 'Despesas', data: dados.despesas, backgroundColor: '#ef4444', borderRadius: 4 }
            ]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            scales: {
                y: { beginAtZero: true, grid: { color: 'rgba(255, 255, 255, 0.05)' }, ticks: { color: '#94a3b8' } },
                x: { grid: { display: false }, ticks: { color: '#94a3b8' } }
            },
            plugins: { legend: { labels: { color: '#f8fafc' } } }
        }
    });
}

function processarDadosParaPizzas(lancamentos) {
    let totalDinheiro = 0; let totalCartao = 0; let categorias = {};
    lancamentos.forEach(l => {
        if (l.tipo === 'gasto') {
            const pag = l.pagamento.toLowerCase();
            if (['pix', 'dinheiro', 'boleto', 'saldo em conta'].includes(pag)) {
                totalDinheiro += l.valor;
            } else { totalCartao += l.valor; }
            categorias[l.categoria] = (categorias[l.categoria] || 0) + l.valor;
        }
    });

    const canvasPgto = document.getElementById('paymentPieChart');
    const canvasCat = document.getElementById('categoryPieChart');
    if (!canvasPgto || !canvasCat) return;

    if (totalDinheiro === 0 && totalCartao === 0) {
        canvasPgto.parentElement.innerHTML = '<p class="no-cards-msg" style="margin-top:70px;">Sem dados suficientes.</p>';
        canvasCat.parentElement.innerHTML = '<p class="no-cards-msg" style="margin-top:70px;">Sem dados suficientes.</p>';
        return;
    }

    // Desenha as Pizzas
    renderizarPizza(canvasPgto.getContext('2d'), ['Dinheiro / PIX', 'Cartão'], [totalDinheiro, totalCartao], ['#10b981', '#8b5cf6']);

    const catLabels = Object.keys(categorias);
    const catData = Object.values(categorias);
    const cores = ['#3b82f6', '#f59e0b', '#ef4444', '#10b981', '#8b5cf6', '#ec4899', '#06b6d4'];
    renderizarPizza(canvasCat.getContext('2d'), catLabels, catData, cores.slice(0, catLabels.length));
}

function renderizarPizza(ctx, labels, data, cores) {
    new Chart(ctx, {
        type: 'doughnut',
        data: { labels: labels, datasets: [{ data: data, backgroundColor: cores, borderWidth: 0, hoverOffset: 4 }] },
        options: { responsive: true, maintainAspectRatio: false, cutout: '70%', plugins: { legend: { position: 'bottom', labels: { color: '#94a3b8', padding: 20, font: { size: 11 } } } } }
    });
}

function renderizarWidgetCartoes(cartoes) {
    const container = document.getElementById('cards-widget-container');
    if (!container) return;
    container.innerHTML = '';
    if (!cartoes || cartoes.length === 0) {
        container.innerHTML = '<p class="no-cards-msg">Nenhum cartão registrado.</p>';
        return;
    }
    cartoes.forEach(card => {
        const percUso = card.limite > 0 ? (card.fatura / card.limite) * 100 : 0;
        const cardHtml = `
            <div class="card-mini-stat">
                <div class="card-mini-top">
                    <div class="card-mini-name">
                        <span class="material-symbols-rounded" style="color:${card.cor};">credit_card</span>
                        ${card.nome}
                    </div>
                    <h3 class="card-mini-fatura">${formatarMoeda(card.fatura)}</h3>
                </div>
                <div class="card-mini-details">
                    <p><span class="limit-label">Limite Disponível:</span> ${formatarMoeda(card.limite - card.fatura)}</p>
                    <p><span class="limit-label">Dia Fechamento:</span> ${card.fechamento}</p>
                </div>
                <div class="progress-mini-bar">
                    <div class="progress-fill" style="width:${percUso}%; background-color:${card.cor};"></div>
                </div>
            </div>
        `;
        container.innerHTML += cardHtml;
    });
}