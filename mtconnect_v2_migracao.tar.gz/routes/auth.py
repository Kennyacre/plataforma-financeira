from fastapi import APIRouter, HTTPException, Depends
from core.database import get_db_connection
from models.schemas import LoginRequest, PerfilUpdate, ManualRegistrationRequest
import logging
from pydantic import BaseModel
from psycopg2.extras import RealDictCursor
import urllib.request
import json

router = APIRouter(prefix="/api", tags=["Autenticacao"])

class GoogleToken(BaseModel):
    token: str

GOOGLE_CLIENT_ID = "139133595751-m3o2umo5v37s9ddl0r2dks99gkr8gc9r.apps.googleusercontent.com"

@router.post("/auth/google")
def login_google(request: GoogleToken):
    try:
        url = f"https://oauth2.googleapis.com/tokeninfo?id_token={request.token}"
        req = urllib.request.Request(url)
        
        with urllib.request.urlopen(req) as response:
            idinfo = json.loads(response.read())
            if idinfo.get('aud') != GOOGLE_CLIENT_ID:
                raise HTTPException(status_code=401, detail="Token inválido.")
            email_google = idinfo.get('email')
            if not email_google:
                raise HTTPException(status_code=401, detail="E-mail não fornecido.")

        conn = get_db_connection()
        cur = conn.cursor()
        try:
            # SEGURANÇA: Só permite login se não estiver deletado
            cur.execute("SELECT username, role, revendedor FROM usuarios WHERE email = %s AND deletado = FALSE", (email_google,))
            user = cur.fetchone()
            
            if user:
                precisa_indicacao = True if not user[2] and user[1] == 'cliente' else False
                return {
                    "status": "sucesso", "role": user[1], "username": user[0], 
                    "email": email_google, "novo_usuario": precisa_indicacao
                }
            else:
                # Novo usuário ou estava na lixeira (se estava na lixeira com esse email, o INSERT falharia se não tratássemos)
                # Verifica se existe na lixeira para avisar
                cur.execute("SELECT id FROM usuarios WHERE email = %s AND deletado = TRUE", (email_google,))
                if cur.fetchone():
                    raise HTTPException(status_code=403, detail="Este e-mail está associado a uma conta na lixeira. Contacte o suporte.")

                import time
                username_sugerido = email_google.split('@')[0].lower().strip()
                try:
                    cur.execute("""
                        INSERT INTO usuarios (username, email, role, status, vencimento) 
                        VALUES (%s, %s, 'cliente', 'ativo', CURRENT_DATE + INTERVAL '30 days')
                    """, (username_sugerido, email_google))
                    conn.commit()
                except:
                    conn.rollback()
                    username_sugerido = f"{username_sugerido}_{int(time.time()) % 1000}"
                    cur.execute("""
                        INSERT INTO usuarios (username, email, role, status, vencimento) 
                        VALUES (%s, %s, 'cliente', 'ativo', CURRENT_DATE + INTERVAL '30 days')
                    """, (username_sugerido, email_google))
                    conn.commit()

                return {
                    "status": "sucesso", "role": "cliente", "username": username_sugerido, 
                    "email": email_google, "novo_usuario": True
                }
        finally:
            cur.close(); conn.close()
    except HTTPException: raise
    except Exception as e:
        logging.error(f"Erro login Google: {e}")
        raise HTTPException(status_code=401, detail="Erro na autenticação Google.")

@router.post("/login")
def login(request: LoginRequest):
    conn = get_db_connection()
    cur = conn.cursor()
    try:
        cur.execute("""
            SELECT username, password, role, status, deletado
            FROM usuarios 
            WHERE (username = %s OR email = %s) AND deletado = FALSE
        """, (request.username.lower().strip(), request.username.lower().strip()))
        
        user = cur.fetchone()
        if not user:
            raise HTTPException(status_code=401, detail="Utilizador não encontrado ou inativo.")
            
        if user[1] != request.password:
            raise HTTPException(status_code=401, detail="Senha incorreta.")
            
        if user[3] == 'bloqueado':
            raise HTTPException(status_code=403, detail="A sua conta está bloqueada.")
            
        return {"status": "sucesso", "role": user[2], "username": user[0]}
    finally:
        cur.close(); conn.close()

@router.post("/cadastro-manual")
def cadastro_manual(dados: ManualRegistrationRequest):
    conn = get_db_connection()
    cur = conn.cursor()
    try:
        username = dados.username.lower().strip()
        email = dados.email.lower().strip()

        cur.execute("SELECT id FROM usuarios WHERE username = %s OR email = %s", (username, email))
        if cur.fetchone():
            raise HTTPException(status_code=400, detail="Utilizador ou E-mail já em uso.")
        
        gestor = None
        if dados.id_indicacao:
            cur.execute("SELECT username FROM usuarios WHERE id = %s AND deletado = FALSE", (dados.id_indicacao,))
            res = cur.fetchone()
            if res: gestor = res[0]
            
        from datetime import date, timedelta
        vencimento = date.today() + timedelta(days=30)
        
        cur.execute("""
            INSERT INTO usuarios (username, password, email, nome_completo, role, revendedor, vencimento, status)
            VALUES (%s, %s, %s, %s, 'cliente', %s, %s, 'ativo')
        """, (username, dados.password, email, dados.nome_completo, gestor, vencimento))
        
        conn.commit()
        return {"status": "sucesso", "mensagem": "Registo concluído!"}
    except HTTPException: raise
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close(); conn.close()

@router.get("/usuarios/perfil/{username}")
def get_perfil(username: str):
    conn = get_db_connection()
    cur = conn.cursor(cursor_factory=RealDictCursor)
    try:
        cur.execute("SELECT username, email, role, revendedor, nome_completo, vencimento FROM usuarios WHERE username = %s AND deletado = FALSE", (username,))
        user = cur.fetchone()
        if not user:
            raise HTTPException(status_code=404, detail="Perfil não encontrado.")
        return user
    finally:
        cur.close(); conn.close()

@router.put("/usuarios/perfil/{username}")
def update_perfil(username: str, data: PerfilUpdate):
    conn = get_db_connection()
    cur = conn.cursor()
    try:
        cur.execute("UPDATE usuarios SET nome_completo = %s, email = %s WHERE username = %s AND deletado = FALSE", (data.nome_completo, data.email.lower().strip(), username))
        conn.commit()
        return {"status": "sucesso", "mensagem": "Perfil atualizado!"}
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close(); conn.close()

@router.get("/usuarios/sessao/{username}")
def check_sessao(username: str):
    conn = get_db_connection()
    cur = conn.cursor()
    try:
        cur.execute("SELECT status, vencimento FROM usuarios WHERE username = %s AND deletado = FALSE", (username,))
        res = cur.fetchone()
        if not res:
            raise HTTPException(status_code=404, detail="Sessão inválida ou utilizador removido.")
        
        status, vencimento = res
        from datetime import date
        dias_restantes = (vencimento - date.today()).days if vencimento else None
            
        return {
            "status": status,
            "vencimento_data": vencimento.strftime("%d/%m/%Y") if vencimento else None,
            "dias_restantes": dias_restantes
        }
    finally:
        cur.close(); conn.close()

@router.get("/admin/info-indicacao/{usuario_id}")
def get_info_indicacao(usuario_id: int):
    conn = get_db_connection()
    cur = conn.cursor()
    try:
        cur.execute("SELECT username, role, nome_completo FROM usuarios WHERE id = %s AND deletado = FALSE", (usuario_id,))
        res = cur.fetchone()
        if not res: raise HTTPException(status_code=404, detail="Indicação não encontrada.")
        return {"username": res[0], "role": res[1], "nome": res[2] or res[0]}
    finally:
        cur.close(); conn.close()

@router.post("/vincular-indicacao")
def vincular_indicacao(dados: dict):
    # dados format: {username: str, indicacao_id: int}
    conn = get_db_connection()
    cur = conn.cursor()
    try:
        cur.execute("SELECT username FROM usuarios WHERE id = %s AND deletado = FALSE", (dados['indicacao_id'],))
        padrinho = cur.fetchone()
        if not padrinho: raise HTTPException(status_code=404, detail="Gestor não encontrado.")
        
        cur.execute("UPDATE usuarios SET revendedor = %s WHERE username = %s", (padrinho[0], dados['username']))
        conn.commit()
        return {"status": "sucesso"}
    except Exception as e:
        conn.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        cur.close(); conn.close()
