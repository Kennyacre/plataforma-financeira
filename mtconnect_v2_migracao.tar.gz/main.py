from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from core.database import startup_db
from routes import auth, revenda, admin, financeiro 

app = FastAPI(title="API TN INFO MODULAR")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def on_startup():
    startup_db()

# Aqui ligamos o motor de Login e os outros!
app.include_router(auth.router)
# app.include_router(revenda.router)  # Arquivado para ideias futuras
app.include_router(admin.router)
app.include_router(financeiro.router)

app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")